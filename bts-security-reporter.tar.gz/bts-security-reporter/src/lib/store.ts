import type { ReportJob } from "./types";

// Pluggable job store. Uses a KV-compatible Redis in production (set
// KV_REST_API_URL and KV_REST_API_TOKEN) and falls back to an in-memory map
// for local dev. Vercel KV is now provided via Upstash Redis on the Vercel
// Marketplace; the @vercel/kv client works against that store's REST API.
// To use @upstash/redis directly instead, swap the import and the KvLike impl.
//
// NOTE: serverless functions are stateless and ephemeral, so the in-memory
// fallback only works when a single process handles create + read (local dev).
// In production you MUST use KV (or swap in Postgres) or jobs will vanish
// between requests.

const KEY_PREFIX = "report:job:";
const INDEX_KEY = "report:jobs:index";

interface KvLike {
  get<T>(key: string): Promise<T | null>;
  set(key: string, value: unknown): Promise<unknown>;
  lpush(key: string, value: string): Promise<unknown>;
  lrange(key: string, start: number, stop: number): Promise<string[]>;
}

let kv: KvLike | null = null;
const mem = new Map<string, ReportJob>();
const memIndex: string[] = [];

async function getKv(): Promise<KvLike | null> {
  if (kv) return kv;
  if (!process.env.KV_REST_API_URL) return null;
  const mod = await import("@vercel/kv");
  kv = mod.kv as unknown as KvLike;
  return kv;
}

export async function saveJob(job: ReportJob): Promise<void> {
  job.updatedAt = new Date().toISOString();
  const store = await getKv();
  if (store) {
    const existed = await store.get<ReportJob>(KEY_PREFIX + job.id);
    await store.set(KEY_PREFIX + job.id, job);
    if (!existed) await store.lpush(INDEX_KEY, job.id);
  } else {
    if (!mem.has(job.id)) memIndex.unshift(job.id);
    mem.set(job.id, job);
  }
}

export async function getJob(id: string): Promise<ReportJob | null> {
  const store = await getKv();
  if (store) return store.get<ReportJob>(KEY_PREFIX + id);
  return mem.get(id) ?? null;
}

export async function listJobs(limit = 50): Promise<ReportJob[]> {
  const store = await getKv();
  if (store) {
    const ids = await store.lrange(INDEX_KEY, 0, limit - 1);
    const jobs = await Promise.all(ids.map((id) => store.get<ReportJob>(KEY_PREFIX + id)));
    return jobs.filter((j): j is ReportJob => Boolean(j));
  }
  return memIndex.slice(0, limit).map((id) => mem.get(id)!).filter(Boolean);
}
