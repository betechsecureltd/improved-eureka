// Render HTML to a PDF buffer. Works both locally (full puppeteer) and on
// Vercel serverless (@sparticuz/chromium + puppeteer-core).

export async function htmlToPdf(html: string): Promise<Buffer> {
  const isServerless = Boolean(process.env.AWS_LAMBDA_FUNCTION_VERSION || process.env.VERCEL);

  if (isServerless) {
    const chromium = (await import("@sparticuz/chromium")).default;
    const puppeteer = await import("puppeteer-core");
    const browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: true,
    });
    try {
      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: "networkidle0" });
      const pdf = await page.pdf({ format: "A4", printBackground: true });
      return Buffer.from(pdf);
    } finally {
      await browser.close();
    }
  }

  // Local/dev path: full puppeteer (bundles its own Chromium).
  const puppeteer = await import("puppeteer");
  const browser = await puppeteer.launch({ headless: true });
  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: "networkidle0" });
    const pdf = await page.pdf({ format: "A4", printBackground: true });
    return Buffer.from(pdf);
  } finally {
    await browser.close();
  }
}
